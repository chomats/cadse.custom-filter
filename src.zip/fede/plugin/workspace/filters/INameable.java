package fede.plugin.workspace.filters;

public interface INameable {
	String getName();
}

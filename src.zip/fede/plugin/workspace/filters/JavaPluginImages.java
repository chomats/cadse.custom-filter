package fede.plugin.workspace.filters;

import org.eclipse.jface.resource.ImageDescriptor;


public class JavaPluginImages {

	public static final ImageDescriptor DESC_ELCL_FILTER = null;
	public static final ImageDescriptor DESC_DLCL_FILTER = null;

}

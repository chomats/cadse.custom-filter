package fede.too.workspace.filters;

public interface INameable {
	String getName();
}
